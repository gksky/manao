<?php

$pageTitle = 'Registration - Users';
require(__DIR__ . '/usercheck.php');
require(__DIR__ . '/src/views/register.php');